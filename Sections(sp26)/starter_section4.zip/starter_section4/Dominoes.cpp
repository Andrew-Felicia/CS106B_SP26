using namespace std;


int numWaysToTile(int n) {
    return 0;
}


/* * * * * Test Cases Below This Point * * * * */
#include "GUI/SimpleTest.h"
PROVIDED_TEST("Examples from handout") {
    EXPECT_EQUAL(numWaysToTile(1), 1);
    EXPECT_EQUAL(numWaysToTile(2), 2);
    EXPECT_EQUAL(numWaysToTile(3), 3);
}

