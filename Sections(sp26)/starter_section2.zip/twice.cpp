/*
 * CS106B Section Handout Test Harness: Section 2
 * ----------------------------------------------
 * These problems have been galvanized from years of
 * section handouts that have been worked on by numerous
 * instructors and TA's. Codified by Trip Master and Nick
 * Bowman for CS106B.
 *
 * A huge thank you to Keith Schwarz and Julie Zelenski
 * for creating an amazing testing harness!
 */

#include <iostream>
#include "SimpleTest.h"
#include "set.h"
#include "vector.h"
using namespace std;

/*
 * twice (Code Writing)
 * --------------------------------------------------------
 * Write a function named twice that takes a vector of integers and returns
 * a set containing all the numbers in the vector that appear exactly twice.
 */

Set<int> twice(Vector<int>& v) {
    // your code here
    return {};
}


/* * * * * Provided Tests Below This Point * * * * */
PROVIDED_TEST("Test from handout") {
    Vector<int> v = {1, 3, 1, 4, 3, 7, -2, 0, 7, -2, -2, 1};
    EXPECT_EQUAL(twice(v), {3, 7});
}

