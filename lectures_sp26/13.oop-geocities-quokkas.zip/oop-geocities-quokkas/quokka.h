// Quokka class.
//
// Author: Sean Szumlanski
// Date: Spring 2026
//
// This library implements a basic Quokka class as an introduction to object-
// oriented programming concepts.

#ifndef QUOKKA_H
#define QUOKKA_H

#include <iostream>

class Quokka
{
public:
    Quokka();
    Quokka(std::string name, int howAdorable, std::string image);
    ~Quokka();
    void printInfo();
    std::string getName();
    void setName(std::string name);
    int howAdorable();
    std::string location();
    std::string image();
    void renderProfile();

private:
    std::string _name;
    int _howAdorable;  // 1 through 5
    std::string _location;
    std::string _image;
};

#endif
